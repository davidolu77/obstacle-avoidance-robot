This library is old and deprecated - and the hardware disconinued years ago. V2 of the shield uses i2c only and works with anything that has I2C support (e.g. all arduinos) without endless incompatibilities and porting requirements! :)
-> https://www.adafruit.com/products/1438

--------------

This is the August 12, 2009 Adafruit Motor shield firmware with basic Microstepping support. Works with all Arduinos and the Mega
Updated in September 2012 for use on PIC32 architecture (chipKIT/MPIDE)

For more information on the shield, please visit https://learn.adafruit.com/adafruit-motor-shield

To install, click DOWNLOAD SOURCE in the top right corner, and see our tutorial at http://www.ladyada.net/library/arduino/libraries.html on Arduino Library installation
